<p align="center">
   <img src="https://images.discordapp.net/avatars/445176711030767616/8beccd63bef72119dfd0c4da74959472.png?size=512" width="200" />
<h2 align="center">Lithium</h2>
<p align="center">
   <a href="https://discord.me/passive"><img src="https://img.shields.io/badge/Invite-PassiveModding-7289DA.svg?longCache=true&style=flat-square&logo=discord"/></a>
   <a href="https://discordapp.com/oauth2/authorize?client_id=445176711030767616&scope=bot&permissions=2146958591"><img src="https://img.shields.io/badge/Invite-Lithium-7289DA.svg?longCache=true&style=flat-square&logo=discord"/></a>
   <br/>
   <a href="https://www.buymeacoffee.com/Passive" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/black_img.png" alt="Buy Me A Coffee" style="height: auto !important;width: auto !important;" ></a>
</p>
</p>

### `Features`
Moderation - Ban, Kick, Warn, Mute, Softban, Mute with Expiry time, autokick after too many warns

Antispam - AntiSpam, AutoRemove @everyone and @here, messages with 5+ role or user mentions, blacklist, remove discord invites, remove IP addresses, Google Perspective Toxicity API

Mod Logging

AutoWarn

& More!!!
### `Contributing`
Feel free to make a pull request, I would love to see everyone's input!